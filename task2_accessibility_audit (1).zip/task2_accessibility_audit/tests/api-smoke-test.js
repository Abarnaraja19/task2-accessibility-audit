// Run the server first (cd server && npm install && npm start), then run this file.
const assert = require("node:assert/strict");

async function main() {
  const response = await fetch("http://localhost:3000/api/services?q=passport");
  assert.equal(response.status, 200);
  const data = await response.json();
  assert.ok(Array.isArray(data.services));
  assert.ok(data.services.some((service) => service.name === "Passport Services"));
  console.log("API smoke test passed.");
}

main().catch((error) => {
  console.error("API smoke test failed:", error.message);
  process.exitCode = 1;
});
