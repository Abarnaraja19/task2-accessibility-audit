const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

const services = [
  { name: "Passport Services", description: "Information about passport application and renewal." },
  { name: "Health Services", description: "Public health information and service links." },
  { name: "Education Services", description: "Information about education programmes and resources." },
  { name: "Digital Locker", description: "Information about secure digital document access." }
];

app.use(express.static(path.join(__dirname, "..", "client")));

app.get("/api/services", (req, res) => {
  const query = String(req.query.q || "").toLowerCase().trim();
  const matches = services.filter((service) =>
    `${service.name} ${service.description}`.toLowerCase().includes(query)
  );
  res.json({ services: matches });
});

app.listen(PORT, () => {
  console.log(`Public Service Directory running at http://localhost:${PORT}`);
});
