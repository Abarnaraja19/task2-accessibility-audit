# Architecture

## Overview

This repository uses a simple client/server split:

```text
Browser
  |
  | HTTP
  v
Client (HTML, CSS, JavaScript)
  |
  | GET /api/services?q=...
  v
Node.js + Express server
  |
  v
In-memory sample public-service data
```

## Boundaries
- `client/` contains the accessible user interface and browser-side interactions.
- `server/` exposes a small JSON API.
- `docs/` contains the audit, architecture notes, and screenshots.
- `tests/` contains a lightweight API smoke test.

## First vertical feature slice
The sample feature is a public-service directory search:
1. A user enters a service name.
2. The client sends the query to `/api/services`.
3. The server filters sample service records.
4. The client renders results in a labelled results region.

This is a learning scaffold inspired by public-service information portals. It is not affiliated with or an official reproduction of india.gov.in.
