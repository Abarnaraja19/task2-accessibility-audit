# Accessibility & Architecture Audit Report

## 1. Website audited
- **Name:** National Portal of India
- **URL:** https://www.india.gov.in/
- **Method:** Chrome Lighthouse report and visual inspection of the supplied screenshots
- **Audit date shown in screenshots:** 23 November 2026

## 2. Lighthouse scores

| Category | Score |
|---|---:|
| Performance | 26 |
| Accessibility | 86 |
| Best Practices | 92 |
| SEO | 100 |

The Lighthouse run displayed a warning that the page loaded too slowly to finish within the time limit, so some results may be incomplete.

## 3. Findings and remediation

### Finding 1 — ARIA roles lack required parent elements
- **Type:** Accessibility
- **Evidence:** Lighthouse Accessibility > ARIA reports: “`[role]s are not contained by their required parent element`”.
- **Impact:** Assistive technologies may not interpret the relationship and structure of affected components correctly.
- **Priority:** High
- **Recommendation:** Prefer semantic HTML. Where ARIA roles are necessary, ensure each role is placed within its required parent structure and follows the ARIA authoring pattern.

### Finding 2 — Insufficient colour contrast
- **Type:** Accessibility
- **Evidence:** Lighthouse Accessibility > Contrast reports: “Background and foreground colors do not have a sufficient contrast ratio.”
- **Impact:** Some text may be difficult to read for people with low vision or colour-vision differences.
- **Priority:** High
- **Recommendation:** Adjust foreground/background colour combinations and verify them against WCAG contrast requirements.

### Finding 3 — Invalid list-item containment
- **Type:** Accessibility
- **Evidence:** Lighthouse Accessibility > Tables and Lists reports: “List items (`<li>`) are not contained within `<ul>`, `<ol>` or `<menu>` parent elements.”
- **Impact:** Screen readers may not announce the content as a properly structured list.
- **Priority:** High
- **Recommendation:** Place every `<li>` inside a valid `<ul>`, `<ol>`, or `<menu>` element, or replace it with a suitable semantic element.

### Finding 4 — Images do not have explicit dimensions
- **Type:** Performance / architecture
- **Evidence:** Lighthouse diagnostics show: “Image elements do not have explicit width and height.”
- **Impact:** The browser may not reserve the correct space before images load, which can contribute to layout shifts.
- **Priority:** Medium
- **Recommendation:** Provide image `width` and `height` attributes or reserve space using CSS `aspect-ratio`.

### Finding 5 — Excessive JavaScript execution and unused JavaScript
- **Type:** Performance / architecture
- **Evidence:** Lighthouse diagnostics show JavaScript execution time of 6.6 s, main-thread work of 53.7 s, and estimated unused JavaScript savings of 293 KB.
- **Impact:** Heavy script execution can delay interaction and make the page feel slow.
- **Priority:** High
- **Recommendation:** Remove unused dependencies, split code into smaller bundles, lazy-load non-critical features, and defer scripts that are not needed for initial rendering.

## 4. Evidence files
- `evidence/lighthouse-scores.png` — overall Lighthouse scores and timeout warning.
- `evidence/accessibility-failures.png` — ARIA, contrast, and list failures.
- `evidence/performance-diagnostics.png` — JavaScript and image-dimension diagnostics.
- `evidence/best-practices.png` — additional Best Practices observation (not counted as one of the five findings).

## 5. Scope and limitations
The findings above are limited to what is visible in the supplied Lighthouse screenshots. Keyboard-only testing and source-code inspection of the reference website were not completed. No keyboard-accessibility defect is claimed without evidence.
