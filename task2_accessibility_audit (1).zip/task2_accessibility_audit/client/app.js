const form = document.querySelector("#search-form");
const input = document.querySelector("#service-query");
const status = document.querySelector("#status");
const results = document.querySelector("#results");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const query = input.value.trim();
  results.replaceChildren();

  if (!query) {
    status.textContent = "Please enter a service name.";
    input.focus();
    return;
  }

  status.textContent = "Searching…";
  try {
    const response = await fetch(`/api/services?q=${encodeURIComponent(query)}`);
    if (!response.ok) throw new Error("Search request failed");
    const data = await response.json();

    if (data.services.length === 0) {
      status.textContent = "No matching services found.";
      return;
    }

    for (const service of data.services) {
      const item = document.createElement("li");
      const heading = document.createElement("strong");
      heading.textContent = service.name;
      const description = document.createElement("p");
      description.textContent = service.description;
      item.append(heading, description);
      results.append(item);
    }
    status.textContent = `${data.services.length} service(s) found.`;
  } catch {
    status.textContent = "Unable to search right now. Please try again.";
  }
});
