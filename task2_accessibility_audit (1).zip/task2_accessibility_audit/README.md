# Accessibility Baseline & Repository Architecture Audit

## Project
A starter full-stack project based on an audit of the National Portal of India.

**Reference website:** https://www.india.gov.in/

## Audit snapshot
Lighthouse results recorded from the supplied screenshots:

| Category | Score |
|---|---:|
| Performance | 26 |
| Accessibility | 86 |
| Best Practices | 92 |
| SEO | 100 |

The audit screenshots show three Accessibility failures and additional performance/architecture opportunities. The five findings are separated by type below; performance findings are not mislabeled as accessibility failures.

## Five documented findings

1. **ARIA parent structure** — Lighthouse reports that elements with roles are not contained by their required parent element. Fix the semantic/ARIA hierarchy.
2. **Insufficient colour contrast** — Lighthouse reports that background and foreground colours do not have a sufficient contrast ratio. Adjust text/background colours and verify contrast.
3. **Invalid list structure** — Lighthouse reports that list items are not contained within `ul`, `ol`, or `menu` parent elements. Use valid semantic list markup.
4. **Images missing explicit dimensions** — Lighthouse diagnostics report image elements without explicit width and height. Add intrinsic dimensions or an aspect-ratio reservation to reduce layout shifts.
5. **Heavy JavaScript work** — Lighthouse diagnostics report 6.6 s JavaScript execution time, 53.7 s main-thread work, and an estimated 293 KB of unused JavaScript savings. Split bundles, defer non-critical scripts, and remove unused code.

## Repository layout

```text
task2_accessibility_audit/
├── client/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── server/
│   ├── package.json
│   └── server.js
├── docs/
│   ├── accessibility-audit-report.md
│   ├── architecture.md
│   └── evidence/
└── tests/
    └── api-smoke-test.js
```

## Run locally

Requirements: Node.js 18 or newer.

1. Open a terminal in the `server` folder.
2. Run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000`.

The demo implements a small accessible public-service directory search vertical slice. It is a starter project, not a copy of the Government of India website.

## Test
With the server running, open another terminal in the project root and run:

```bash
node tests/api-smoke-test.js
```

## Evidence
Screenshots captured during the audit are stored in `docs/evidence/`. They document the Lighthouse scores and visible audit findings.

## Important limitation
The screenshots support the three Accessibility failures and the two performance/architecture findings above. Keyboard-only checks were not completed, so no keyboard issue is claimed as a confirmed finding.
